document.addEventListener("DOMContentLoaded", () => {

    // =========================
    // PRODUCTS
    // =========================

    const products = [
        {
            id: 1,
            name: "Smartphone Pro 5G",
            category: "mobiles",
            price: 24999,
            oldPrice: 29999,
            rating: 4.5,
            image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=600",
            description: "Powerful 5G smartphone with a premium display and long-lasting battery."
        },
        {
            id: 2,
            name: "Wireless Headphones",
            category: "electronics",
            price: 1499,
            oldPrice: 2499,
            rating: 4.3,
            image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600",
            description: "Comfortable wireless headphones with clear sound and deep bass."
        },
        {
            id: 3,
            name: "Smart Watch",
            category: "electronics",
            price: 1999,
            oldPrice: 2999,
            rating: 4.2,
            image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600",
            description: "Modern smartwatch with fitness tracking and notifications."
        },
        {
            id: 4,
            name: "Men's Casual Shirt",
            category: "fashion",
            price: 799,
            oldPrice: 1299,
            rating: 4.1,
            image: "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=600",
            description: "Comfortable casual shirt suitable for everyday use."
        },
        {
            id: 5,
            name: "Running Shoes",
            category: "fashion",
            price: 1299,
            oldPrice: 1999,
            rating: 4.4,
            image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600",
            description: "Lightweight running shoes designed for daily comfort."
        },
        {
            id: 6,
            name: "Kitchen Mixer",
            category: "home",
            price: 2299,
            oldPrice: 3499,
            rating: 4.0,
            image: "https://images.unsplash.com/photo-1570222094114-d054a817e56b?w=600",
            description: "Powerful kitchen mixer for everyday cooking needs."
        },
        {
            id: 7,
            name: "Face Care Kit",
            category: "beauty",
            price: 599,
            oldPrice: 999,
            rating: 4.2,
            image: "https://images.unsplash.com/photo-1556228720-195a672e8a03?w=600",
            description: "Daily face care kit for a simple skincare routine."
        },
        {
            id: 8,
            name: "Organic Rice 5kg",
            category: "grocery",
            price: 499,
            oldPrice: 599,
            rating: 4.5,
            image: "https://images.unsplash.com/photo-1586201375761-83865001e31c?w=600",
            description: "Quality rice suitable for everyday meals."
        },
        {
            id: 9,
            name: "Bluetooth Speaker",
            category: "electronics",
            price: 999,
            oldPrice: 1599,
            rating: 4.3,
            image: "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=600",
            description: "Portable Bluetooth speaker with powerful audio."
        },
        {
            id: 10,
            name: "Laptop Backpack",
            category: "fashion",
            price: 899,
            oldPrice: 1499,
            rating: 4.4,
            image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=600",
            description: "Durable backpack with laptop compartment and multiple pockets."
        }
    ];


    // =========================
    // LOCAL STORAGE
    // =========================

    let cart =
        JSON.parse(localStorage.getItem("shophub_cart")) || [];

    let wishlist =
        JSON.parse(localStorage.getItem("shophub_wishlist")) || [];

    let currentCategory = "all";


    // =========================
    // ELEMENTS
    // =========================

    const productGrid =
        document.getElementById("productGrid");

    const searchInput =
        document.getElementById("searchInput");

    const searchBtn =
        document.getElementById("searchBtn");

    const cartBtn =
        document.getElementById("cartBtn");

    const cartCount =
        document.getElementById("cartCount");

    const cartOverlay =
        document.getElementById("cartOverlay");

    const cartSidebar =
        document.getElementById("cartSidebar");

    const closeCartBtn =
        document.getElementById("closeCartBtn");

    const cartItems =
        document.getElementById("cartItems");

    const cartTotal =
        document.getElementById("cartTotal");

    const checkoutBtn =
        document.getElementById("checkoutBtn");

    const loginModal =
        document.getElementById("loginModal");

    const closeLoginBtn =
        document.getElementById("closeLoginBtn");

    const loginEmail =
        document.getElementById("loginEmail");

    const loginPassword =
        document.getElementById("loginPassword");

    const submitLoginBtn =
        document.getElementById("submitLoginBtn");


    // =========================
    // FORMAT PRICE
    // =========================

    function formatPrice(price) {
        return "₹" + Number(price).toLocaleString("en-IN");
    }


    // =========================
    // OPEN PRODUCT
    // =========================

    function openProduct(id) {

        const product = products.find(
            item => item.id === Number(id)
        );

        if (!product) return;

        localStorage.setItem(
            "selected_product",
            JSON.stringify(product)
        );

        window.location.href =
            "pages/product.html";
    }


    // =========================
    // RENDER PRODUCTS
    // =========================

    function renderProducts() {

        if (!productGrid) return;

        const searchText =
            searchInput ?
            searchInput.value.trim().toLowerCase() :
            "";

        const filteredProducts =
            products.filter(product => {

                const categoryMatch =
                    currentCategory === "all" ||
                    product.category === currentCategory;

                const searchMatch =
                    product.name.toLowerCase().includes(searchText);

                return categoryMatch && searchMatch;
            });


        if (filteredProducts.length === 0) {

            productGrid.innerHTML = `
                <div class="no-products">
                    <h3>No products found</h3>
                    <p>Try another search or category.</p>
                </div>
            `;

            return;
        }


        productGrid.innerHTML =
            filteredProducts.map(product => {

                const liked =
                    wishlist.includes(product.id);

                const discount =
                    product.oldPrice > product.price
                    ? Math.round(
                        ((product.oldPrice - product.price) /
                        product.oldPrice) * 100
                    )
                    : 0;

                return `
                    <div class="product-card">

                        <button
                            class="wishlist-btn ${liked ? "active" : ""}"
                            data-wishlist-id="${product.id}"
                            title="Wishlist"
                        >
                            ${liked ? "♥" : "♡"}
                        </button>

                        <div
                            class="product-image"
                            data-product-id="${product.id}"
                        >
                            <img
                                src="${product.image}"
                                alt="${product.name}"
                            >
                        </div>

                        <div
                            class="product-name"
                            data-product-id="${product.id}"
                        >
                            ${product.name}
                        </div>

                        <div class="product-rating">
                            ⭐ ${product.rating}
                        </div>

                        <div class="product-price">
                            ${formatPrice(product.price)}
                        </div>

                        <div class="product-old-price">
                            ${formatPrice(product.oldPrice)}
                            ${
                                discount > 0
                                ? `<span class="product-discount">
                                    ${discount}% off
                                   </span>`
                                : ""
                            }
                        </div>

                        <button
                            class="add-cart-btn"
                            data-cart-id="${product.id}"
                        >
                            Add to Cart
                        </button>

                    </div>
                `;
            }).join("");
    }


    // =========================
    // PRODUCT CLICK
    // =========================

    if (productGrid) {

        productGrid.addEventListener(
            "click",
            function(event) {

                // Wishlist
                const wishlistTarget =
                    event.target.closest(
                        "[data-wishlist-id]"
                    );

                if (wishlistTarget) {

                    const id =
                        Number(
                            wishlistTarget.dataset.wishlistId
                        );

                    toggleWishlist(id);

                    return;
                }


                // Add to cart
                const cartTarget =
                    event.target.closest(
                        "[data-cart-id]"
                    );

                if (cartTarget) {

                    const id =
                        Number(
                            cartTarget.dataset.cartId
                        );

                    addToCart(id);

                    return;
                }


                // Product
                const productTarget =
                    event.target.closest(
                        "[data-product-id]"
                    );

                if (productTarget) {

                    const id =
                        Number(
                            productTarget.dataset.productId
                        );

                    openProduct(id);

                    return;
                }
            }
        );
    }


    // =========================
    // CART
    // =========================

    function saveCart() {

        localStorage.setItem(
            "shophub_cart",
            JSON.stringify(cart)
        );

        updateCartCount();
    }


    function updateCartCount() {

        if (!cartCount) return;

        const count =
            cart.reduce(
                (total, item) =>
                    total + Number(item.quantity || 1),
                0
            );

        cartCount.textContent = count;
    }


    function addToCart(id) {

        const product =
            products.find(
                item => item.id === Number(id)
            );

        if (!product) return;


        const existing =
            cart.find(
                item => item.id === product.id
            );


        if (existing) {

            existing.quantity =
                Number(existing.quantity || 1) + 1;

        } else {

            cart.push({
                ...product,
                quantity: 1
            });
        }


        saveCart();

        renderCart();

        showToast("Product added to cart");
    }


    function removeFromCart(id) {

        cart =
            cart.filter(
                item => item.id !== Number(id)
            );

        saveCart();

        renderCart();
    }


    function changeQuantity(id, change) {

        const item =
            cart.find(
                product => product.id === Number(id)
            );

        if (!item) return;


        item.quantity =
            Number(item.quantity || 1) + change;


        if (item.quantity <= 0) {

            removeFromCart(id);

            return;
        }


        saveCart();

        renderCart();
    }


    function renderCart() {

        if (!cartItems) return;


        if (cart.length === 0) {

            cartItems.innerHTML = `
                <div class="empty-cart">
                    <h3>Your cart is empty</h3>
                    <p>Add some products to continue.</p>
                </div>
            `;

            if (cartTotal) {
                cartTotal.textContent = "₹0";
            }

            return;
        }


        cartItems.innerHTML =
            cart.map(item => {

                const quantity =
                    Number(item.quantity || 1);

                return `
                    <div class="cart-item">

                        <img
                            src="${item.image}"
                            alt="${item.name}"
                        >

                        <div class="cart-item-info">

                            <h4>${item.name}</h4>

                            <strong>
                                ${formatPrice(item.price)}
                            </strong>

                            <div class="quantity-controls">

                                <button
                                    data-minus-id="${item.id}"
                                >
                                    −
                                </button>

                                <span>${quantity}</span>

                                <button
                                    data-plus-id="${item.id}"
                                >
                                    +
                                </button>

                            </div>

                            <button
                                class="remove-cart-item"
                                data-remove-id="${item.id}"
                            >
                                Remove
                            </button>

                        </div>

                    </div>
                `;
            }).join("");


        const total =
            cart.reduce(
                (sum, item) =>
                    sum +
                    Number(item.price) *
                    Number(item.quantity || 1),
                0
            );


        if (cartTotal) {

            cartTotal.textContent =
                formatPrice(total);
        }
    }


    // =========================
    // CART BUTTON EVENTS
    // =========================

    if (cartItems) {

        cartItems.addEventListener(
            "click",
            function(event) {

                const plus =
                    event.target.closest(
                        "[data-plus-id]"
                    );

                if (plus) {

                    changeQuantity(
                        Number(plus.dataset.plusId),
                        1
                    );

                    return;
                }


                const minus =
                    event.target.closest(
                        "[data-minus-id]"
                    );

                if (minus) {

                    changeQuantity(
                        Number(minus.dataset.minusId),
                        -1
                    );

                    return;
                }


                const remove =
                    event.target.closest(
                        "[data-remove-id]"
                    );

                if (remove) {

                    removeFromCart(
                        Number(remove.dataset.removeId)
                    );
                }
            }
        );
    }


    function openCart() {

        if (!cartOverlay) return;

        cartOverlay.classList.add("show");

        renderCart();
    }


    function closeCart() {

        if (!cartOverlay) return;

        cartOverlay.classList.remove("show");
    }


    if (cartBtn) {

        cartBtn.addEventListener(
            "click",
            openCart
        );
    }


    if (closeCartBtn) {

        closeCartBtn.addEventListener(
            "click",
            closeCart
        );
    }


    if (cartOverlay) {

        cartOverlay.addEventListener(
            "click",
            function(event) {

                if (
                    event.target === cartOverlay
                ) {
                    closeCart();
                }
            }
        );
    }


    // =========================
    // CHECKOUT
    // =========================

    if (checkoutBtn) {

        checkoutBtn.addEventListener(
            "click",
            function() {

                if (cart.length === 0) {

                    showToast(
                        "Your cart is empty"
                    );

                    return;
                }

                window.location.href =
                    "pages/checkout.html";
            }
        );
    }


    // =========================
    // WISHLIST
    // =========================

    function toggleWishlist(id) {

        id = Number(id);

        if (wishlist.includes(id)) {

            wishlist =
                wishlist.filter(
                    item => item !== id
                );

            showToast(
                "Removed from wishlist"
            );

        } else {

            wishlist.push(id);

            showToast(
                "Added to wishlist"
            );
        }


        localStorage.setItem(
            "shophub_wishlist",
            JSON.stringify(wishlist)
        );

        renderProducts();
    }


    // =========================
    // SEARCH
    // =========================

    function performSearch() {

        currentCategory = "all";

        renderProducts();

        if (productGrid) {

            productGrid.scrollIntoView({
                behavior: "smooth",
                block: "start"
            });
        }
    }


    if (searchBtn) {

        searchBtn.addEventListener(
            "click",
            performSearch
        );
    }


    if (searchInput) {

        searchInput.addEventListener(
            "keydown",
            function(event) {

                if (event.key === "Enter") {

                    performSearch();
                }
            }
        );
    }


    // =========================
    // CATEGORY FILTER
    // =========================

    const categoryButtons =
        document.querySelectorAll(
            "[data-category]"
        );


    categoryButtons.forEach(
        function(button) {

            button.addEventListener(
                "click",
                function() {

                    currentCategory =
                        button.dataset.category;

                    renderProducts();

                    if (productGrid) {

                        productGrid.scrollIntoView({
                            behavior: "smooth",
                            block: "start"
                        });
                    }
                }
            );
        }
    );


    // =========================
    // SHOP NOW
    // =========================

    const shopNowBtn =
        document.getElementById("shopNowBtn");


    if (shopNowBtn) {

        shopNowBtn.addEventListener(
            "click",
            function() {

                if (