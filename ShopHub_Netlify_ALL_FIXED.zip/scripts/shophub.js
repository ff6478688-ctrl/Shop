/* =========================================
   SHOPHUB - MAIN JAVASCRIPT
   INVENTORY / STOCK ENABLED
========================================= */

const DEFAULT_STOCK = 10;


/* =========================================
   DEFAULT PRODUCTS
========================================= */

const defaultProducts = [
    { id: 1, name: "True Wireless Earbuds", category: "earbuds", price: 999, oldPrice: 1599, rating: 4.3, stock: 10, image: "https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?w=600" },
    { id: 2, name: "Bass Boost Earbuds", category: "earbuds", price: 1299, oldPrice: 1999, rating: 4.4, stock: 10, image: "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=600" },
    { id: 3, name: "Wireless Headphones", category: "headphones", price: 1499, oldPrice: 2499, rating: 4.3, stock: 10, image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600" },
    { id: 4, name: "Over-Ear Headphones", category: "headphones", price: 1999, oldPrice: 2999, rating: 4.5, stock: 10, image: "https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=600" },
    { id: 5, name: "RGB Gaming Keyboard", category: "keyboard", price: 1299, oldPrice: 1999, rating: 4.4, stock: 10, image: "https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=600" },
    { id: 6, name: "Wireless Keyboard", category: "keyboard", price: 899, oldPrice: 1399, rating: 4.2, stock: 10, image: "https://images.unsplash.com/photo-1587825140708-dfaf72ae4b04?w=600" },
    { id: 7, name: "Gaming Mouse", category: "mouse", price: 699, oldPrice: 1099, rating: 4.3, stock: 10, image: "https://images.unsplash.com/photo-1527814050087-3793815479db?w=600" },
    { id: 8, name: "Wireless Mouse", category: "mouse", price: 499, oldPrice: 799, rating: 4.2, stock: 10, image: "https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=600" },
    { id: 9, name: "Kids Building Toy", category: "toys", price: 599, oldPrice: 899, rating: 4.5, stock: 10, image: "https://images.unsplash.com/photo-1594787318286-3d835c1d207f?w=600" },
    { id: 10, name: "Remote Control Car", category: "toys", price: 999, oldPrice: 1499, rating: 4.4, stock: 10, image: "https://images.unsplash.com/photo-1594787318286-3d835c1d207f?w=600" },
    { id: 11, name: "Science Knowledge Book", category: "books", price: 299, oldPrice: 399, rating: 4.6, stock: 10, image: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=600" },
    { id: 12, name: "Learning & Activity Book", category: "books", price: 249, oldPrice: 349, rating: 4.4, stock: 10, image: "https://images.unsplash.com/photo-1512820790803-83ca734da794?w=600" },
    { id: 13, name: "Mystery Novel", category: "novels", price: 349, oldPrice: 499, rating: 4.5, stock: 10, image: "https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=600" },
    { id: 14, name: "Fiction Story Novel", category: "novels", price: 399, oldPrice: 599, rating: 4.6, stock: 10, image: "https://images.unsplash.com/photo-1511108690759-009324a90311?w=600" }
];


/* =========================================
   GET ADMIN PRODUCTS
========================================= */

function getAdminProducts() {

    try {

        const raw =
            localStorage.getItem("shophub_products");

        if (!raw) {
            return [];
        }

        const parsed = JSON.parse(raw);

        return Array.isArray(parsed)
            ? parsed
            : [];

    } catch (error) {

        console.warn(
            "ShopHub: unable to read admin products from localStorage.",
            error
        );

        return [];

    }

}


/* =========================================
   NORMALIZE PRODUCT
========================================= */

function normalizeProduct(product) {

    return {

        ...product,

        stock:
            Math.max(
                0,
                Number.isFinite(
                    Number(product.stock)
                )
                    ? Number(product.stock)
                    : DEFAULT_STOCK
            )

    };

}


/* =========================================
   ALL PRODUCTS
========================================= */

function getAllProducts() {

    const adminProducts =
        getAdminProducts();


    return [

        ...defaultProducts.map(
            normalizeProduct
        ),

        ...adminProducts.map(
            normalizeProduct
        )

    ];

}


let products =
    getAllProducts();


/* =========================================
   LOCAL STORAGE
========================================= */

let cart = [];

try {

    cart =
        JSON.parse(
            localStorage.getItem(
                "shophub_cart"
            )
        ) || [];

} catch (error) {

    cart = [];

}


let wishlist = [];

try {

    wishlist =
        JSON.parse(
            localStorage.getItem(
                "shophub_wishlist"
            )
        ) || [];

} catch (error) {

    wishlist = [];

}


let currentCategory =
    "all";


/* =========================================
   ELEMENT HELPER
========================================= */

function getElement(id) {

    return document.getElementById(id);

}


/* =========================================
   MONEY FORMAT
========================================= */

function money(amount) {

    return "₹" +
        Number(amount || 0)
            .toLocaleString("en-IN");

}


/* =========================================
   SAVE CART
========================================= */

function saveCart() {

    localStorage.setItem(
        "shophub_cart",
        JSON.stringify(cart)
    );

}


/* =========================================
   SAVE WISHLIST
========================================= */

function saveWishlist() {

    localStorage.setItem(
        "shophub_wishlist",
        JSON.stringify(wishlist)
    );

}


/* =========================================
   TOAST
========================================= */

function showToast(message) {

    let toast =
        getElement("toast");


    if (!toast) {

        toast =
            document.createElement("div");

        toast.id =
            "toast";


        toast.style.position =
            "fixed";

        toast.style.bottom =
            "25px";

        toast.style.left =
            "50%";

        toast.style.transform =
            "translateX(-50%)";

        toast.style.background =
            "#222";

        toast.style.color =
            "#fff";

        toast.style.padding =
            "12px 20px";

        toast.style.borderRadius =
            "6px";

        toast.style.zIndex =
            "99999";

        toast.style.maxWidth =
            "90%";

        toast.style.textAlign =
            "center";


        document.body.appendChild(
            toast
        );

    }


    toast.textContent =
        message;

    toast.style.display =
        "block";


    clearTimeout(
        window.shopHubToastTimer
    );


    window.shopHubToastTimer =
        setTimeout(
            function() {

                toast.style.display =
                    "none";

            },
            1800
        );

}


/* =========================================
   CART COUNT
========================================= */

function updateCartCount() {

    const cartCount =
        getElement("cartCount");


    if (!cartCount) {

        return;

    }


    const totalQuantity =
        cart.reduce(
            function(total, item) {

                return total +
                    Number(
                        item.qty || 1
                    );

            },
            0
        );


    cartCount.textContent =
        totalQuantity;

}


/* =========================================
   PRODUCT BY ID
========================================= */

function getProductById(id) {

    products =
        getAllProducts();


    return products.find(
        function(item) {

            return String(item.id) ===
                String(id);

        }
    );

}


/* =========================================
   AVAILABLE STOCK
========================================= */

function getAvailableStock(id) {

    const product =
        getProductById(id);


    if (!product) {

        return 0;

    }


    return Math.max(
        0,
        Number(
            product.stock || 0
        )
    );

}
/* =========================================
   ADD TO CART
========================================= */

function addToCart(id) {

    const product =
        getProductById(id);


    if (!product) {

        showToast(
            "Product not found"
        );

        return;

    }


    const stock =
        getAvailableStock(id);


    if (stock <= 0) {

        showToast(
            "Out of Stock"
        );

        return;

    }


    const existing =
        cart.find(
            function(item) {

                return Number(item.id) ===
                    Number(id);

            }
        );


    if (existing) {

        const currentQty =
            Number(
                existing.qty || 1
            );


        if (currentQty >= stock) {

            showToast(
                "Only " +
                stock +
                " item(s) available"
            );

            return;

        }


        existing.qty =
            currentQty + 1;

        existing.stock =
            stock;

    } else {

        cart.push({

            ...product,

            qty: 1,

            stock: stock

        });

    }


    saveCart();

    updateCartCount();

    renderCartSidebar();


    showToast(
        product.name +
        " added to cart"
    );

}


/* =========================================
   REMOVE FROM CART
========================================= */

function removeFromCart(id) {

    cart =
        cart.filter(
            function(item) {

                return Number(item.id) !==
                    Number(id);

            }
        );


    saveCart();

    updateCartCount();

    renderCartSidebar();

}


/* =========================================
   CHANGE CART QUANTITY
========================================= */

function changeCartQuantity(
    id,
    change
) {

    const item =
        cart.find(
            function(product) {

                return Number(product.id) ===
                    Number(id);

            }
        );


    if (!item) {

        return;

    }


    const liveStock =
        getAvailableStock(id);


    if (
        change > 0 &&
        Number(item.qty || 1) >=
        liveStock
    ) {

        showToast(

            liveStock > 0

                ? "Only " +
                  liveStock +
                  " item(s) available"

                : "Out of Stock"

        );

        return;

    }


    item.qty =
        Number(item.qty || 1) +
        Number(change);


    if (item.qty <= 0) {

        cart =
            cart.filter(
                function(product) {

                    return Number(product.id) !==
                        Number(id);

                }
            );

    } else {

        item.stock =
            liveStock;

    }


    saveCart();

    updateCartCount();

    renderCartSidebar();

}


/* =========================================
   OPEN CART
========================================= */

function openCart() {

    renderCartSidebar();


    const overlay =
        getElement(
            "cartOverlay"
        );


    const sidebar =
        getElement(
            "cartSidebar"
        );


    if (overlay) {

        overlay.classList.add(
            "show"
        );

    }


    if (sidebar) {

        sidebar.classList.add(
            "show"
        );

    }

}


/* =========================================
   CLOSE CART
========================================= */

function closeCart() {

    const overlay =
        getElement(
            "cartOverlay"
        );


    const sidebar =
        getElement(
            "cartSidebar"
        );


    if (overlay) {

        overlay.classList.remove(
            "show"
        );

    }


    if (sidebar) {

        sidebar.classList.remove(
            "show"
        );

    }

}


/* =========================================
   RENDER CART SIDEBAR
========================================= */

function renderCartSidebar() {

    const container =
        getElement(
            "cartItems"
        );


    const totalElement =
        getElement(
            "cartTotal"
        );


    if (!container) {

        return;

    }


    if (cart.length === 0) {

        container.innerHTML = `

            <div
                style="
                    text-align:center;
                    padding:30px 10px;
                    color:#777;
                "
            >

                🛒 Your cart is empty

            </div>

        `;


        if (totalElement) {

            totalElement.textContent =
                money(0);

        }


        return;

    }


    let total = 0;


    container.innerHTML =

        cart.map(
            function(item) {

                const quantity =
                    Number(
                        item.qty || 1
                    );


                const liveStock =
                    getAvailableStock(
                        item.id
                    );


                if (liveStock <= 0) {

                    return `

                        <div
                            style="
                                padding:12px 0;
                                border-bottom:1px solid #eee;
                            "
                        >

                            <div
                                style="
                                    font-weight:bold;
                                "
                            >

                                ${item.name}

                            </div>


                            <div
                                style="
                                    color:#e53935;
                                    margin-top:5px;
                                "
                            >

                                Out of Stock

                            </div>


                            <button
                                onclick="
                                    removeFromCart(
                                        ${item.id}
                                    )
                                "
                                style="
                                    margin-top:8px;
                                    border:none;
                                    background:none;
                                    color:#e53935;
                                    cursor:pointer;
                                "
                            >

                                Remove

                            </button>

                        </div>

                    `;

                }


                const safeQty =
                    Math.min(
                        quantity,
                        liveStock
                    );


                if (
                    safeQty !==
                    quantity
                ) {

                    item.qty =
                        safeQty;

                }


                const itemTotal =
                    Number(
                        item.price || 0
                    ) *
                    safeQty;


                total +=
                    itemTotal;


                return `

                    <div
                        style="
                            display:flex;
                            gap:10px;
                            padding:12px 0;
                            border-bottom:1px solid #eee;
                        "
                    >

                        <img
                            src="${item.image || ""}"
                            style="
                                width:65px;
                                height:65px;
                                object-fit:contain;
                                border-radius:5px;
                            "
                            onerror="
                                this.style.display='none'
                            "
                        >


                        <div
                            style="
                                flex:1;
                            "
                        >

                            <div
                                style="
                                    font-weight:bold;
                                    font-size:14px;
                                "
                            >

                                ${item.name}

                            </div>


                            <div
                                style="
                                    margin-top:5px;
                                    color:#2874f0;
                                    font-weight:bold;
                                "
                            >

                                ${money(
                                    item.price
                                )}

                            </div>


                            <div
                                style="
                                    font-size:11px;
                                    color:#777;
                                    margin-top:4px;
                                "
                            >

                                ${liveStock}
                                available

                            </div>


                            <div
                                style="
                                    display:flex;
                                    align-items:center;
                                    gap:8px;
                                    margin-top:8px;
                                "
                            >

                                <button
                                    onclick="
                                        changeCartQuantity(
                                            ${item.id},
                                            -1
                                        )
                                    "
                                    style="
                                        width:28px;
                                        height:28px;
                                        border:1px solid #ddd;
                                        background:white;
                                        border-radius:4px;
                                    "
                                >

                                    −

                                </button>


                                <span>

                                    ${safeQty}

                                </span>


                                <button
                                    onclick="
                                        changeCartQuantity(
                                            ${item.id},
                                            1
                                        )
                                    "
                                    style="
                                        width:28px;
                                        height:28px;
                                        border:1px solid #ddd;
                                        background:white;
                                        border-radius:4px;
                                    "
                                >

                                    +

                                </button>


                                <button
                                    onclick="
                                        removeFromCart(
                                            ${item.id}
                                        )
                                    "
                                    style="
                                        margin-left:auto;
                                        border:none;
                                        background:none;
                                        color:#e53935;
                                        cursor:pointer;
                                    "
                                >

                                    Remove

                                </button>

                            </div>

                        </div>

                    </div>

                `;

            }
        ).join("");


    saveCart();


    if (totalElement) {

        totalElement.textContent =
            money(total);

    }

}
/* =========================================
   OPEN PRODUCT DETAILS
========================================= */

function openProduct(id) {

    const product =
        getProductById(id);


    if (!product) {

        showToast(
            "Product not found"
        );

        return;

    }


    localStorage.setItem(
        "selected_product",
        JSON.stringify(product)
    );


    window.location.href =
        "Pages/product.html?id=" + encodeURIComponent(product.id);

}


/* =========================================
   DISCOUNT PERCENTAGE
========================================= */

function getDiscount(product) {

    if (
        !product ||
        !product.oldPrice ||
        product.oldPrice <= product.price
    ) {

        return 0;

    }


    return Math.round(

        (
            (
                product.oldPrice -
                product.price
            ) /
            product.oldPrice
        ) * 100

    );

}


/* =========================================
   RENDER PRODUCTS
========================================= */

function renderProducts(
    productList = null
) {

    const grid =
        getElement(
            "productGrid"
        );


    if (!grid) {

        return;

    }


    products =
        getAllProducts();


    let list =
        productList || products;


    if (
        currentCategory &&
        currentCategory !== "all"
    ) {

        list =
            list.filter(
                function(product) {

                    return (
                        product.category ===
                        currentCategory
                    );

                }
            );

    }


    if (list.length === 0) {

        grid.innerHTML = `

            <div
                style="
                    grid-column:1/-1;
                    text-align:center;
                    padding:40px 15px;
                    color:#777;
                "
            >

                <div
                    style="
                        font-size:40px;
                        margin-bottom:10px;
                    "
                >

                    🔍

                </div>


                <h3>

                    No products found

                </h3>


                <p>

                    Try another search or category.

                </p>

            </div>

        `;

        return;

    }


    grid.innerHTML =

        list.map(
            function(product) {

                const discount =
                    getDiscount(
                        product
                    );


                const stock =
                    Math.max(
                        0,
                        Number(
                            product.stock || 0
                        )
                    );


                let stockText = "";
                let stockStyle = "";


                if (stock <= 0) {

                    stockText =
                        "Out of Stock";

                    stockStyle =
                        "color:#e53935;";

                } else if (stock <= 3) {

                    stockText =
                        "Only " +
                        stock +
                        " left";

                    stockStyle =
                        "color:#ff6f00;";

                } else {

                    stockText =
                        "In Stock";

                    stockStyle =
                        "color:#168a35;";

                }


                const isWishlisted =
                    wishlist.some(
                        function(id) {

                            return Number(id) ===
                                Number(product.id);

                        }
                    );


                return `

                    <div
                        class="product-card"
                    >

                        <div
                            class="product-image"
                            onclick="
                                openProduct(
                                    ${product.id}
                                )
                            "
                            style="
                                cursor:pointer;
                                position:relative;
                            "
                        >

                            <img
                                src="${product.image || ""}"
                                alt="${product.name}"
                                onerror="
                                    this.src='https://via.placeholder.com/300x300?text=Product'
                                "
                            >


                            ${
                                discount > 0
                                    ? `
                                        <span
                                            style="
                                                position:absolute;
                                                top:8px;
                                                left:8px;
                                                background:#0b8f3c;
                                                color:white;
                                                padding:4px 7px;
                                                border-radius:4px;
                                                font-size:11px;
                                                font-weight:bold;
                                            "
                                        >

                                            ${discount}% OFF

                                        </span>
                                    `
                                    : ""
                            }


                            <button
                                class="wishlist-btn"
                                onclick="
                                    event.stopPropagation();
                                    toggleWishlist(
                                        ${product.id}
                                    )
                                "
                                title="Wishlist"
                            >

                                ${
                                    isWishlisted
                                        ? "❤️"
                                        : "♡"
                                }

                            </button>

                        </div>


                        <div
                            class="product-info"
                        >

                            <div
                                class="product-name"
                                onclick="
                                    openProduct(
                                        ${product.id}
                                    )
                                "
                                style="
                                    cursor:pointer;
                                "
                            >

                                ${product.name}

                            </div>


                            <div
                                class="product-rating"
                            >

                                ⭐
                                ${product.rating || 0}

                            </div>


                            <div
                                class="product-price"
                            >

                                <span
                                    class="current-price"
                                >

                                    ${money(
                                        product.price
                                    )}

                                </span>


                                ${
                                    product.oldPrice
                                        ? `
                                            <span
                                                class="product-old-price"
                                            >

                                                ${money(
                                                    product.oldPrice
                                                )}

                                            </span>
                                        `
                                        : ""
                                }


                                ${
                                    discount > 0
                                        ? `
                                            <span
                                                class="product-discount"
                                            >

                                                ${discount}% off

                                            </span>
                                        `
                                        : ""
                                }

                            </div>


                            <div
                                style="
                                    margin:5px 0 8px;
                                    font-size:12px;
                                    font-weight:600;
                                    ${stockStyle}
                                "
                            >

                                ${stockText}

                            </div>


                            <button
                                class="add-cart-btn"
                                onclick="
                                    addToCart(
                                        ${product.id}
                                    )
                                "
                                ${
                                    stock <= 0
                                        ? "disabled"
                                        : ""
                                }
                                style="
                                    ${
                                        stock <= 0
                                            ? "opacity:.55;cursor:not-allowed;"
                                            : ""
                                    }
                                "
                            >

                                ${
                                    stock <= 0
                                        ? "Out of Stock"
                                        : "Add to Cart"
                                }

                            </button>

                        </div>

                    </div>

                `;

            }
        ).join("");

}


/* =========================================
   TOGGLE WISHLIST
========================================= */

function toggleWishlist(id) {

    const numericId =
        Number(id);


    if (
        !Number.isFinite(
            numericId
        )
    ) {

        return;

    }


    const index =
        wishlist.findIndex(
            function(itemId) {

                return Number(itemId) ===
                    numericId;

            }
        );


    if (index !== -1) {

        wishlist.splice(
            index,
            1
        );


        showToast(
            "Removed from wishlist"
        );

    } else {

        wishlist.push(
            numericId
        );


        showToast(
            "Added to wishlist ❤️"
        );

    }


    saveWishlist();


    renderProducts();

}
/* =========================================
   SEARCH PRODUCTS
========================================= */

function searchProducts() {

    const input =
        getElement(
            "searchInput"
        );


    if (!input) {

        return;

    }


    const query =
        input.value
            .trim()
            .toLowerCase();


    products =
        getAllProducts();


    let filtered =
        products;


    if (query) {

        filtered =
            products.filter(
                function(product) {

                    return (

                        String(
                            product.name || ""
                        )
                        .toLowerCase()
                        .includes(query)

                        ||

                        String(
                            product.category || ""
                        )
                        .toLowerCase()
                        .includes(query)

                    );

                }
            );

    }


    if (
        currentCategory &&
        currentCategory !== "all"
    ) {

        filtered =
            filtered.filter(
                function(product) {

                    return (
                        product.category ===
                        currentCategory
                    );

                }
            );

    }


    renderProducts(
        filtered
    );

}


/* =========================================
   GET CURRENT USER
========================================= */

function getCurrentUser() {

    try {

        return JSON.parse(
            localStorage.getItem(
                "shophub_current_user"
            )
        );

    } catch (error) {

        return null;

    }

}


/* =========================================
   UPDATE ACCOUNT UI
========================================= */

function updateAccountUI() {

    const accountArea =
        getElement(
            "accountArea"
        );


    if (!accountArea) {

        return;

    }


    const user =
        getCurrentUser();


    if (!user) {

        accountArea.innerHTML = `

            <button
                id="loginBtn"
                type="button"
            >

                👤 Login

            </button>

        `;

        return;

    }


    const userName =
        user.name ||
        user.email ||
        "Account";


    accountArea.innerHTML = `

        <div
            class="account-menu"
        >

            <button
                class="account-btn"
                id="accountBtn"
                type="button"
            >

                👤
                ${userName}

                ▾

            </button>


            <div
                class="account-dropdown"
                id="accountDropdown"
            >

                <a
                    href="Pages/orders.html"
                >

                    📦 My Orders

                </a>


                <a
                    href="Pages/wishlist.html"
                >

                    ❤️ Wishlist

                </a>


                <button
                    type="button"
                    id="logoutBtn"
                >

                    🚪 Logout

                </button>

            </div>

        </div>

    `;


    const accountBtn =
        getElement(
            "accountBtn"
        );


    const dropdown =
        getElement(
            "accountDropdown"
        );


    if (accountBtn && dropdown) {

        accountBtn.addEventListener(
            "click",
            function(event) {

                event.stopPropagation();

                dropdown.classList.toggle(
                    "show"
                );

            }
        );

    }


    const logoutBtn =
        getElement(
            "logoutBtn"
        );


    if (logoutBtn) {

        logoutBtn.addEventListener(
            "click",
            function() {

                localStorage.removeItem(
                    "shophub_current_user"
                );


                showToast(
                    "Logged out successfully"
                );


                setTimeout(
                    function() {

                        updateAccountUI();

                    },
                    300
                );

            }
        );

    }

}


/* =========================================
   CLOSE LOGIN MODAL
========================================= */

function closeLoginModal() {

    const modal =
        getElement(
            "loginModal"
        );


    if (modal) {

        modal.style.display =
            "none";

        modal.classList.remove(
            "show"
        );

    }

}
/* =========================================
   INIT SHOPHUB
========================================= */

function initShopHub() {

    /* -----------------------------------------
       REFRESH PRODUCTS
    ----------------------------------------- */

    products =
        getAllProducts();


    /* -----------------------------------------
       RENDER PRODUCTS
    ----------------------------------------- */

    renderProducts();


    /* -----------------------------------------
       CART COUNT
    ----------------------------------------- */

    updateCartCount();


    /* -----------------------------------------
       ACCOUNT
    ----------------------------------------- */

    updateAccountUI();


    /* -----------------------------------------
       SEARCH BUTTON
    ----------------------------------------- */

    const searchBtn =
        getElement(
            "searchBtn"
        );


    if (searchBtn) {

        searchBtn.addEventListener(
            "click",
            function() {

                searchProducts();

            }
        );

    }


    /* -----------------------------------------
       SEARCH ENTER KEY
    ----------------------------------------- */

    const searchInput =
        getElement(
            "searchInput"
        );


    if (searchInput) {

        searchInput.addEventListener(
            "keydown",
            function(event) {

                if (
                    event.key ===
                    "Enter"
                ) {

                    searchProducts();

                }

            }
        );


        searchInput.addEventListener(
            "input",
            function() {

                searchProducts();

            }
        );

    }


    /* -----------------------------------------
       CATEGORY BUTTONS
    ----------------------------------------- */

    const categoryButtons =
        document.querySelectorAll(
            "[data-category]"
        );


    categoryButtons.forEach(
        function(button) {

            button.addEventListener(
                "click",
                function() {

                    currentCategory =
                        button.getAttribute(
                            "data-category"
                        ) ||
                        "all";


                    categoryButtons.forEach(
                        function(btn) {

                            btn.classList.remove(
                                "active"
                            );

                        }
                    );


                    button.classList.add(
                        "active"
                    );


                    searchProducts();

                }
            );

        }
    );


    /* -----------------------------------------
       CART BUTTON
    ----------------------------------------- */

    const cartBtn =
        getElement(
            "cartBtn"
        );


    if (cartBtn) {

        cartBtn.addEventListener(
            "click",
            function() {

                openCart();

            }
        );

    }


    /* -----------------------------------------
       CLOSE CART BUTTON
    ----------------------------------------- */

    const closeCartBtn =
        getElement(
            "closeCartBtn"
        );


    if (closeCartBtn) {

        closeCartBtn.addEventListener(
            "click",
            function() {

                closeCart();

            }
        );

    }


    /* -----------------------------------------
       CART OVERLAY
    ----------------------------------------- */

    const cartOverlay =
        getElement(
            "cartOverlay"
        );


    if (cartOverlay) {

        cartOverlay.addEventListener(
            "click",
            function() {

                closeCart();

            }
        );

    }


    /* -----------------------------------------
       WISHLIST BUTTON
    ----------------------------------------- */

    const wishlistBtn =
        getElement(
            "wishlistBtn"
        );


    if (wishlistBtn) {

        wishlistBtn.addEventListener(
            "click",
            function() {

                window.location.href =
                    "Pages/wishlist.html";

            }
        );

    }


    /* -----------------------------------------
       LOGIN BUTTON
    ----------------------------------------- */

    const loginBtn =
        getElement(
            "loginBtn"
        );


    if (loginBtn) {

        loginBtn.addEventListener(
            "click",
            function() {

                const modal =
                    getElement(
                        "loginModal"
                    );


                if (modal) {

                    modal.style.display =
                        "flex";

                    modal.classList.add(
                        "show"
                    );

                }

            }
        );

    }


    /* -----------------------------------------
       CLOSE LOGIN BUTTON
    ----------------------------------------- */

    const closeLoginBtn =
        getElement(
            "closeLoginBtn"
        );


    if (closeLoginBtn) {

        closeLoginBtn.addEventListener(
            "click",
            function() {

                closeLoginModal();

            }
        );

    }


    /* -----------------------------------------
       LOGIN MODAL OUTSIDE CLICK
    ----------------------------------------- */

    const loginModal =
        getElement(
            "loginModal"
        );


    if (loginModal) {

        loginModal.addEventListener(
            "click",
            function(event) {

                if (
                    event.target ===
                    loginModal
                ) {

                    closeLoginModal();

                }

            }
        );

    }


    /* -----------------------------------------
       LOGIN SUBMIT
    ----------------------------------------- */

    const submitLoginBtn =
        getElement(
            "submitLoginBtn"
        );


    if (submitLoginBtn) {

        submitLoginBtn.addEventListener(
            "click",
            function() {

                const emailInput =
                    getElement(
                        "loginEmail"
                    );


                const passwordInput =
                    getElement(
                        "loginPassword"
                    );


                const email =
                    emailInput
                        ? emailInput.value.trim()
                        : "";


                const password =
                    passwordInput
                        ? passwordInput.value
                        : "";


                if (!email) {

                    showToast(
                        "Enter your email"
                    );

                    return;

                }


                if (!email.includes("@")) {

                    showToast(
                        "Enter a valid email"
                    );

                    return;

                }


                if (!password) {

                    showToast(
                        "Enter your password"
                    );

                    return;

                }


                let users = [];


                try {

                    users =
                        JSON.parse(
                            localStorage.getItem(
                                "shophub_users"
                            )
                        ) || [];

                } catch (error) {

                    users = [];

                }


                const user =
                    users.find(
                        function(item) {

                            return (
                                item.email ===
                                email &&
                                item.password ===
                                password
                            );

                        }
                    );


                if (!user) {

                    showToast(
                        "Invalid email or password"
                    );

                    return;

                }


                localStorage.setItem(
                    "shophub_current_user",
                    JSON.stringify(user)
                );


                closeLoginModal();

                updateAccountUI();


                showToast(
                    "Login successful"
                );

            }
        );

    }


    /* -----------------------------------------
       SHOP NOW BUTTON
    ----------------------------------------- */

    const shopNowBtn =
        document.querySelector(
            ".shop-now-btn"
        );


    if (shopNowBtn) {

        shopNowBtn.addEventListener(
            "click",
            function() {

                const productsSection =
                    document.querySelector(
                        "#products"
                    );


                if (productsSection) {

                    productsSection.scrollIntoView({
                        behavior: "smooth"
                    });

                } else {

                    window.scrollTo({
                        top: 500,
                        behavior: "smooth"
                    });

                }

            }
        );

    }


    /* -----------------------------------------
       CHECKOUT BUTTON
    ----------------------------------------- */

    const checkoutBtn =
        getElement(
            "checkoutBtn"
        );


    if (checkoutBtn) {

        checkoutBtn.addEventListener(
            "click",
            function() {

                if (cart.length === 0) {

                    showToast(
                        "Your cart is empty"
                    );

                    return;

                }


                let validCart = true;


                cart.forEach(
                    function(item) {

                        const stock =
                            getAvailableStock(
                                item.id
                            );


                        if (
                            stock <= 0
                        ) {

                            validCart =
                                false;

                        }


                        if (
                            Number(item.qty || 1) >
                            stock
                        ) {

                            item.qty =
                                stock;

                        }

                    }
                );


                cart =
                    cart.filter(
                        function(item) {

                            return (
                                Number(item.qty || 0) >
                                0
                            );

                        }
                    );


                saveCart();

                updateCartCount();


                if (!validCart) {

                    renderCartSidebar();


                    showToast(
                        "Some products are out of stock"
                    );

                    return;

                }


                window.location.href =
                    "Pages/checkout.html";

            }
        );

    }


    /* -----------------------------------------
       CLOSE DROPDOWNS ON OUTSIDE CLICK
    ----------------------------------------- */

    document.addEventListener(
        "click",
        function(event) {

            const dropdown =
                getElement(
                    "accountDropdown"
                );


            const accountMenu =
                document.querySelector(
                    ".account-menu"
                );


            if (
                dropdown &&
                accountMenu &&
                !accountMenu.contains(
                    event.target
                )
            ) {

                dropdown.classList.remove(
                    "show"
                );

            }

        }
    );


    /* -----------------------------------------
       ESCAPE KEY
    ----------------------------------------- */

    document.addEventListener(
        "keydown",
        function(event) {

            if (
                event.key ===
                "Escape"
            ) {

                closeCart();

                closeLoginModal();

            }

        }
    );

}


/* =========================================
   GLOBAL FUNCTIONS
========================================= */

window.addToCart =
    addToCart;

window.removeFromCart =
    removeFromCart;

window.changeCartQuantity =
    changeCartQuantity;

window.openCart =
    openCart;

window.closeCart =
    closeCart;

window.openProduct =
    openProduct;

window.toggleWishlist =
    toggleWishlist;

window.getProductById =
    getProductById;

window.getAvailableStock =
    getAvailableStock;

window.renderProducts =
    renderProducts;

window.searchProducts =
    searchProducts;

window.money =
    money;


/* =========================================
   LIVE PRODUCT STORAGE SYNC
========================================= */

window.addEventListener(
    "storage",
    function(event) {

        if (event.key !== "shophub_products") {
            return;
        }

        products = getAllProducts();

        renderProducts();

    }
);


/* =========================================
   MANUAL PRODUCT DATA REFRESH
========================================= */

window.refreshShopProducts = function() {

    products = getAllProducts();

    renderProducts();

    return products.length;

};


/* =========================================
   START SHOPHUB
========================================= */

if (
    document.readyState ===
    "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        initShopHub
    );

} else {

    initShopHub();

}