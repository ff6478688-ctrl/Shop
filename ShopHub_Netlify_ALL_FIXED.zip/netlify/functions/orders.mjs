import { getStore } from "@netlify/blobs";
import crypto from "node:crypto";

const ADMIN_ID = process.env.SHOPHUB_ADMIN_ID || "sh_admin_KyU3LrgVcFt7vHDB";
const ADMIN_HASH = process.env.SHOPHUB_ADMIN_PASSWORD_HASH || "6e82ccee950235e2eeb98a920396b20be49027af5665fb55a4b674027b8d5521";
const SESSION_SECRET = process.env.SHOPHUB_SESSION_SECRET || ADMIN_HASH;
const COOKIE = "shophub_admin_session";
const STORE = "shophub-orders";

function cors() { return { "Content-Type": "application/json; charset=utf-8", "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "Content-Type", "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS" }; }
function json(data, status=200) { return new Response(JSON.stringify(data), {status, headers:cors()}); }
function isAdmin(request) {
  const cookie = request.headers.get("cookie") || "";
  const match = cookie.match(new RegExp(`${COOKIE}=([^;]+)`));
  if (!match) return false;
  const [payload, sig] = String(match[1]).split(".");
  if (!payload || !sig) return false;
  const expected = crypto.createHmac("sha256", SESSION_SECRET).update(payload).digest("base64url");
  if (sig.length !== expected.length) return false;
  if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return false;
  try { const p=JSON.parse(Buffer.from(payload,"base64url").toString("utf8")); return p.sub===ADMIN_ID && Number(p.exp)>Date.now(); } catch { return false; }
}
async function readOrders(store) { const data=await store.get("orders.json",{type:"json"}); return Array.isArray(data)?data:[]; }
async function writeOrders(store, orders) { await store.setJSON("orders.json", orders); }
function orderId() { return "SH" + Date.now().toString(36).toUpperCase() + crypto.randomBytes(3).toString("hex").toUpperCase(); }

export default async (request) => {
  if (request.method === "OPTIONS") return new Response(null,{status:204,headers:cors()});
  try {
    const store=getStore(STORE);
    const url=new URL(request.url);
    const id=url.searchParams.get("id") || "";
    const orders=await readOrders(store);

    if(request.method === "GET") {
      if(isAdmin(request)) return json({orders});
      const email=String(url.searchParams.get("email")||"").trim().toLowerCase();
      if(!email) return json({error:"Unauthorized"},401);
      return json({orders:orders.filter(o=>String(o.email||"").trim().toLowerCase()===email)});
    }

    if(request.method === "POST") {
      const body=await request.json();
      if(!body || !Array.isArray(body.items) || !body.items.length) return json({error:"Cart is empty"},400);
      const items=body.items.map(i=>({productId:i.productId||i.id||"",id:i.id||i.productId||"",name:String(i.name||"Product"),price:Number(i.price)||0,quantity:Math.max(1,Number(i.quantity)||1)}));
      const subtotal=items.reduce((s,i)=>s+i.price*i.quantity,0);
      const giftDiscount=Math.min(subtotal,Math.max(0,Number(body.giftDiscount)||0));
      const clean={
        id: orderId(),
        order_id: null,
        createdAt:new Date().toISOString(),
        customerName:String(body.customerName||body.shipping?.name||"Customer"),
        customer_email:String(body.email||""),
        email:String(body.email||""),
        customer_phone:String(body.shipping?.phone||body.mobile||""),
        mobile:String(body.shipping?.phone||body.mobile||""),
        shipping_address:String(body.shipping?.address||""),
        address:String(body.shipping?.address||""),
        shipping_city:String(body.shipping?.city||""),
        city:String(body.shipping?.city||""),
        shipping_pincode:String(body.shipping?.pincode||""),
        pincode:String(body.shipping?.pincode||""),
        payment_method:String(body.payment||"Cash on Delivery"),
        payment:String(body.payment||"Cash on Delivery"),
        gift_code:String(body.giftCode||""),
        giftCode:String(body.giftCode||""),
        gift_discount:giftDiscount,
        giftDiscount:giftDiscount,
        items,
        total:Math.max(0,subtotal-giftDiscount),
        status:"Order Placed",
        orderStatus:"Order Placed"
      };
      clean.order_id=clean.id;
      orders.unshift(clean);
      await writeOrders(store,orders);
      return json({order:clean},201);
    }

    if(request.method === "PATCH") {
      if(!isAdmin(request)) return json({error:"Unauthorized"},401);
      if(!id) return json({error:"Order id required"},400);
      const body=await request.json().catch(()=>({}));
      const index=orders.findIndex(o=>String(o.id||o.order_id||o.orderId)===String(id));
      if(index<0) return json({error:"Order not found"},404);
      if(body.status){orders[index].status=String(body.status);orders[index].orderStatus=String(body.status);}
      await writeOrders(store,orders);
      return json({order:orders[index]});
    }

    if(request.method === "DELETE") {
      if(!isAdmin(request)) return json({error:"Unauthorized"},401);
      if(!id) return json({error:"Order id required"},400);
      const filtered=orders.filter(o=>String(o.id||o.order_id||o.orderId)!==String(id));
      if(filtered.length===orders.length) return json({error:"Order not found"},404);
      await writeOrders(store,filtered); return json({ok:true});
    }
    return json({error:"Method not allowed"},405);
  } catch(e) { console.error(e); return json({error:"Server error",detail:e?.message||"Unknown error"},500); }
};
