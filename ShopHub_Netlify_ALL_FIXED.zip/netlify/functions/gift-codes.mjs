import { getStore } from "@netlify/blobs";
import crypto from "node:crypto";
const ADMIN_ID=process.env.SHOPHUB_ADMIN_ID||"sh_admin_KyU3LrgVcFt7vHDB";
const ADMIN_HASH=process.env.SHOPHUB_ADMIN_PASSWORD_HASH||"6e82ccee950235e2eeb98a920396b20be49027af5665fb55a4b674027b8d5521";
const SESSION_SECRET=process.env.SHOPHUB_SESSION_SECRET||ADMIN_HASH;
const COOKIE="shophub_admin_session";
const STORE="shophub-gift-codes";
function headers(){return {"Content-Type":"application/json; charset=utf-8","Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"Content-Type","Access-Control-Allow-Methods":"GET,POST,PATCH,DELETE,OPTIONS"};}
function json(data,status=200){return new Response(JSON.stringify(data),{status,headers:headers()});}
function norm(v){return String(v||"").trim().toUpperCase().replace(/\s+/g,"");}
function isAdmin(request){const c=request.headers.get("cookie")||"";const m=c.match(new RegExp(`${COOKIE}=([^;]+)`));if(!m)return false;const [p,s]=String(m[1]).split(".");if(!p||!s)return false;const exp=crypto.createHmac("sha256",SESSION_SECRET).update(p).digest("base64url");if(s.length!==exp.length||!crypto.timingSafeEqual(Buffer.from(s),Buffer.from(exp)))return false;try{const x=JSON.parse(Buffer.from(p,"base64url").toString("utf8"));return x.sub===ADMIN_ID&&Number(x.exp)>Date.now();}catch{return false;}}
function randomCode(){const chars="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";let out="SHGIFT-";for(let i=0;i<10;i++)out+=chars[crypto.randomInt(chars.length)];return out;}
async function load(){return (await getStore(STORE).get("codes",{type:"json"}))||[];}
async function save(c){await getStore(STORE).setJSON("codes",c);}
export default async request=>{if(request.method==="OPTIONS")return new Response(null,{status:204,headers:headers()});try{let codes=await load();
 if(request.method==="GET"){const code=norm(new URL(request.url).searchParams.get("code"));if(code)return json({gift:codes.find(g=>norm(g.code)===code&&!g.used)||null});return json({codes});}
 const body=await request.json().catch(()=>({}));
 if(request.method==="POST"){if(!isAdmin(request))return json({error:"Unauthorized"},401);const amount=Math.max(1,Number(body.amount)||100),qty=Math.min(50,Math.max(1,Number(body.qty)||1)),custom=norm(body.custom),made=[];for(let i=0;i<qty;i++){let code=i===0&&custom?custom:randomCode();while(codes.some(g=>norm(g.code)===code))code=randomCode();const g={code,amount,used:false,createdAt:new Date().toISOString()};codes.push(g);made.push(g);}await save(codes);return json({codes:made});}
 if(request.method==="PATCH"){const code=norm(body.code);const i=codes.findIndex(g=>norm(g.code)===code&&!g.used);if(i<0)return json({ok:false},404);codes[i]={...codes[i],used:true,usedAt:new Date().toISOString()};await save(codes);return json({ok:true,gift:codes[i]});}
 if(request.method==="DELETE"){if(!isAdmin(request))return json({error:"Unauthorized"},401);const code=norm(body.code);codes=codes.filter(g=>norm(g.code)!==code);await save(codes);return json({ok:true});}
 return json({error:"Method not allowed"},405);
}catch(e){console.error(e);return json({error:e?.message||"Gift code service error"},500);}};
