import crypto from "node:crypto";

const ADMIN_ID = process.env.SHOPHUB_ADMIN_ID || "sh_admin_KyU3LrgVcFt7vHDB";
const ADMIN_HASH = process.env.SHOPHUB_ADMIN_PASSWORD_HASH || "6e82ccee950235e2eeb98a920396b20be49027af5665fb55a4b674027b8d5521";
const SESSION_SECRET = process.env.SHOPHUB_SESSION_SECRET || ADMIN_HASH;
const COOKIE = "shophub_admin_session";

function headers(extra = {}) {
  return {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    ...extra
  };
}
function json(data, status = 200, extra = {}) {
  return new Response(JSON.stringify(data), { status, headers: headers(extra) });
}
function b64(v) { return Buffer.from(v).toString("base64url"); }
function sign(value) { return crypto.createHmac("sha256", SESSION_SECRET).update(value).digest("base64url"); }
function makeSession() {
  const payload = b64(JSON.stringify({ sub: ADMIN_ID, exp: Date.now() + 1000 * 60 * 60 * 24 * 7 }));
  return `${payload}.${sign(payload)}`;
}
function validSession(request) {
  const cookie = request.headers.get("cookie") || "";
  const match = cookie.match(new RegExp(`${COOKIE}=([^;]+)`));
  if (!match) return false;
  const [payload, signature] = String(match[1]).split(".");
  if (!payload || !signature || !crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(sign(payload)))) return false;
  try {
    const data = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
    return data.sub === ADMIN_ID && Number(data.exp) > Date.now();
  } catch { return false; }
}
function cookie(value, maxAge) {
  return `${COOKIE}=${value}; Path=/; Max-Age=${maxAge}; HttpOnly; SameSite=Lax; Secure`;
}

export default async (request) => {
  if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: headers() });
  try {
    if (request.method === "GET") return json({ user: { isAdmin: validSession(request), id: ADMIN_ID } });
    if (request.method === "POST") {
      const body = await request.json().catch(() => ({}));
      const action = body.action || "login";
      if (action === "logout") return json({ ok: true }, 200, { "Set-Cookie": cookie("", 0) });
      const id = String(body.id || "").trim();
      const passwordHash = String(body.passwordHash || "").trim().toLowerCase();
      if (id !== ADMIN_ID || passwordHash !== ADMIN_HASH) return json({ error: "Invalid Admin ID or Password" }, 401);
      return json({ ok: true, user: { isAdmin: true, id: ADMIN_ID } }, 200, { "Set-Cookie": cookie(makeSession(), 60 * 60 * 24 * 7) });
    }
    return json({ error: "Method not allowed" }, 405);
  } catch (e) {
    return json({ error: e?.message || "Auth error" }, 500);
  }
};
